# axialMri > 2025-06-04 1:07pm
https://universe.roboflow.com/phamumbaiuni/axialmri

Provided by a Roboflow user
License: CC BY 4.0

